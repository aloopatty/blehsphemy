class StudyPost {
  final String id, subjectId, sourceName, tag;
  final DateTime createdAt;
  final List<String> cards;
  final List<String> sources;
  final bool saved, mastered, sample;
  const StudyPost({required this.id,required this.subjectId,required this.sourceName,required this.tag,required this.createdAt,required this.cards,required this.sources,this.saved=false,this.mastered=false,this.sample=false});

  factory StudyPost.samplePhysics() => StudyPost(id:'sample-physics',subjectId:'physics',sourceName:'Newtonian Mechanics • Sample',tag:'MECHANICS',createdAt:DateTime.now(),cards:['Newton’s First Law\n\nAn object remains at rest or in uniform motion unless acted upon by a net external force.','Newton’s Second Law\n\nThe net force equals the rate of change of momentum. For constant mass: F = ma.','Newton’s Third Law\n\nFor every action, there is an equal and opposite reaction.'],sources:['Sample • Card 1','Sample • Card 2','Sample • Card 3'],sample:true);
  factory StudyPost.sampleChemistry() => StudyPost(id:'sample-chemistry',subjectId:'organic',sourceName:'Organic Chemistry • Sample',tag:'REACTIONS',createdAt:DateTime.now(),cards:['SN1 Reaction\n\nTwo-step substitution. Rate depends on substrate concentration. A carbocation intermediate forms.','SN2 Reaction\n\nOne-step concerted substitution. Rate depends on substrate and nucleophile. Backside attack causes inversion.'],sources:['Sample • Concept 1','Sample • Concept 2'],sample:true);
  Map<String,dynamic> toMap()=>{'id':id,'subjectId':subjectId,'sourceName':sourceName,'tag':tag,'createdAt':createdAt.toIso8601String(),'cards':cards,'sources':sources,'saved':saved,'mastered':mastered,'sample':sample};
  factory StudyPost.fromMap(Map<String,dynamic> m)=>StudyPost(id:m['id'],subjectId:m['subjectId'],sourceName:m['sourceName'],tag:m['tag']??'STUDY',createdAt:DateTime.parse(m['createdAt']),cards:List<String>.from(m['cards']??[]),sources:List<String>.from(m['sources']??[]),saved:m['saved']??false,mastered:m['mastered']??false,sample:m['sample']??false);
  StudyPost copyWith({bool? saved,bool? mastered})=>StudyPost(id:id,subjectId:subjectId,sourceName:sourceName,tag:tag,createdAt:createdAt,cards:cards,sources:sources,saved:saved??this.saved,mastered:mastered??this.mastered,sample:sample);
}

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'core/storage/study_store.dart';
import 'core/theme/app_theme.dart';
import 'features/app/studygram_app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  await StudyStore.initialize();
  runApp(const ProviderScope(child: StudyGramApp()));
}

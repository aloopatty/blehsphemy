# StudyGram 📚

StudyGram is an offline-first Flutter study app that turns your class materials into a visual learning feed. Subjects behave like separate social accounts; uploaded PDFs, PPTX, DOCX, Markdown and text are parsed locally and transformed into swipeable study posts and quick insight stories.

## Features
- Subject account switcher with sample Physics and Organic Chemistry accounts.
- Glassmorphism feed, ambient gradient, stories, countdown and subject profile.
- Upload multiple supported files and extract content **on-device**.
- PDF page cards, PPTX slide parsing (including notes), DOCX paragraphs/headings and TXT/MD sections.
- Save/bookmark and mastered state; locally persisted via Hive.
- Story viewer with tap navigation, pause, swipe-down close and source attribution.
- Deadline countdown editable per subject.
- Dark and light themes.

## Run locally
1. Install Flutter stable and Android Studio / Android SDK.
2. `flutter pub get`
3. `flutter run`

## Tests
`flutter test`

## Release APK
GitHub Actions runs on pushes to `main` and manual dispatch:
1. Open **GitHub → Actions → Build StudyGram APK**.
2. Open the latest successful run.
3. Download **studygram-release-apk** under Artifacts.

The workflow runs `flutter analyze`, `flutter test`, and builds a release APK.

## Offline parsing
Files are processed on-device. StudyGram does not upload study materials. PDFs use Syncfusion's Flutter PDF text extraction, Office files are ZIP/XML parsed, and text/Markdown are sectioned by headings.

## Publish this project to GitHub

The included portable Git bundle preserves the complete local commit history.

```bash
git clone studygram.bundle studygram
cd studygram
gh repo create studygram --public --source=. --remote=origin --push
```

If you prefer creating the repository in GitHub's web UI, create an empty repository named `studygram`, then:

```bash
git remote add origin https://github.com/YOUR_USERNAME/studygram.git
git push -u origin main
```

## Notes
- Sample accounts are clearly labelled sample content.
- The first version uses Hive boxes and lightweight domain models. No account or cloud service is required.
- This source snapshot has not been compiled in the build environment because Flutter/Dart and the Android SDK are not installed here. The Actions workflow is configured to run the checks and APK build after pushing.
